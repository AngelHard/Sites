function sliderBackgroundBody() {
window.currBg = window.currBg + 1;
if (!window.currBg || window.currBg > 4) window.currBg = 1;
$('div.container').css('background', 'url(images/bg' + window.currBg + '.jpg) no-repeat center top / cover');

setTimeout(sliderBackgroundBody, 10000);
}
$(document).ready(function() {
sliderBackgroundBody();
});
